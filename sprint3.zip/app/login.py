from flask_wtf import FlaskForm
from wtforms import StringField, EmailField, PasswordField, SubmitField
from wtforms.validators import DataRequired, Email, Length

class login(FlaskForm):
    Usuario = StringField ('Usuario ', validators=[
        DataRequired(message="Rellene informacion"),
        Length(min=3, message='Supere los 3 caracteres')
    ])
    correo = EmailField ('Correo electónico ', validators=[
        DataRequired(message="Rellene informacion"),
        Email(message='Email invalido')
    ])
    password = PasswordField ('Contraseña ', validators=[
        DataRequired(message="Rellene informacion"),
        Length(min=3, message='Supere los 3 caracteres')
    ])
    
    key = StringField ('Key ', validators=[
        DataRequired(message="Rellene informacion"),
        Length(min=6, message='Supere los 6 caracteres')
    ])
    
    ingresa=SubmitField('Ingresa')
    