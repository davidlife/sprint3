from urllib import request
from flask import Flask, render_template, flash, url_for, redirect, g, session
from login import login
from register import Registro
from activate import activar
from messaje import messaje
import yagmail as yagmail
import os
import database
import random
import functools
from flask import (Blueprint, flash, g, redirect, render_template, request, session, url_for)
from werkzeug.security import check_password_hash, generate_password_hash

app=Flask(__name__)
app.secret_key = os.urandom(24)

@app.before_request
def cargarUsuarioLogueado():
    user_id=session.get('user_id')
    if user_id is None:
        g.user= None
    else:
        g.user = database.usuarioSesionActual(user_id)

def login_required(view):
    @functools.wraps(view)
    def wrapped_view(**kwargs):
        if g.user is None:
            flash("Para acceder necesitas estar logueado.")
            return redirect(url_for('index'))
        return view(**kwargs)
    return wrapped_view

@app.route('/', methods=['GET', 'POST'])
def index():
    titulo ="Messaje Xpress Intro" 
    form=login()
    
    if g.user:
        return redirect ( url_for('correos'))
    try:
        if request.method == 'POST':
            correo = form.correo.data
            password = form.password.data
            try:
                if database.validarUsuarioActivo(correo) is True:
                    if database.validarUsuario(correo, password):
                        session.clear()
                        session['user_id']=correo
                        session['user_usuario']=database.consultarUsuario(correo)
                        return redirect ( url_for('correos') )  
                    else:
                        error = '¡usuario o contraseña erroneos!'
                        flash(error)
                        return render_template('index.html', form=form, titulo=titulo)
                else:                  
                    key = database.usuarioConsultarkey(correo)
                    yag = yagmail.SMTP( 'uninortepruebasciclo3@gmail.com' , 'taougyvfvxjvfndp')
                    yag.send(to=correo,
                    subject='Activa tu cuenta '+ correo,
                    contents='<h2>'+ key +' - Este es tu código de verificación.</h2>')
                    error = '¡Usuario registrado pero no activo!'
                    flash(error)
                    session['user_correo']=correo
                    return redirect ( url_for('activate') )                    
            except:
                flash ("Opps no estas registrado. ")
                return render_template('index.html', form=form, titulo=titulo)
                
    except:
        flash("Opps algo salio mal al intentar verificar tu sesion, contacta con soporte")
        return render_template('index.html', form=form, titulo=titulo)
               
    return render_template('index.html', form=form, titulo=titulo)

@app.route('/activate/', methods=['GET', 'POST'])
def activate():
    titulo ="Messaje Xpress Activate" 
    form=activar()
    correo= session['user_correo']  
    try:
        if request.method == 'POST':
            key = form.key.data
            try:
                if database.consultarKey(correo,key):
                    keySend = str(key)
                    try:
                        if database.activarkey(correo,keySend):
                            error = '¡Cuenta activada!'
                            flash(error)
                            return redirect ( url_for('index') )      
                        else:   
                            error =  '¡Cuenta no activada!'
                            flash(error)
                            return redirect ( url_for('activate') )
                    except:
                        flash("Opps algo salio mal, contacta con soporte")
                        return render_template('activate.html', form=form, titulo=titulo, email=correo)
                else:
                    error =  '¡Codigo no es correcto!'
                    flash(error)
                    return redirect ( url_for('activate') )
            except:
                flash("Opps algo salio mal, contacta con soporte")
                return render_template('activate.html', form=form, titulo=titulo, email=correo) 
    except:
        flash("Opps algo salio mal al intentar verificar tu sesion, contacta con soporte")
        return render_template('activate.html', form=form, titulo=titulo, email=correo)
           
    return render_template('activate.html', form=form, titulo=titulo, email=correo)

@app.route('/register/', methods=['GET', 'POST'])
def registro():
    titulo ="Messaje Xpress Register"
    form=Registro()
    usuario=form.usuario.data
    correo=form.correo.data
    password=form.password.data
    passwordRepeat=form.passwordRepeat.data
    
    try:
        if (form.validate_on_submit()):
            
            if database.selectUsuario(usuario):
                error =  '¡El usuario ya esta registrado!'
                flash(error)
                return render_template('register.html', form=form, titulo=titulo)
            
            if database.selectEmail(correo):
                error =  '¡El correo ya esta registrado!'
                flash(error)
                return render_template('register.html', form=form, titulo=titulo)
            
            if(password == passwordRepeat):
                try:
                    passwordHash=generate_password_hash(password)
                    key = random.randint(100000, 999999)
                    keySend = str(key) 
                    database.insert(usuario,correo,passwordHash,key)
                    yag = yagmail.SMTP( 'uninortepruebasciclo3@gmail.com' , 'taougyvfvxjvfndp')
                    yag.send(to=correo,
                    subject='Activa tu cuenta '+ usuario,
                    contents='<h2>'+ keySend +' - Este es tu código de verificación.</h2>')
                    session['user_correo']=correo
                    return redirect ( url_for('activate') )                  
                except:
                    flash ('Correo ya registrado')
                    return render_template('register.html', form=form, titulo=titulo)
            else:
                flash ('La contraseña no coincide.')
                return render_template('register.html', form=form, titulo=titulo)
    except:
        flash("Opps algo salio mal, contacta con soporte")
        return render_template('register.html', form=form, titulo=titulo)  
            
    return render_template('register.html', form=form, titulo=titulo)
        
   
@app.route('/forgot/', methods=['GET', 'POST'])
def forgot():
    titulo ="Messaje Xpress Forgot"
    form=login()
    return render_template('forgot.html', form=form, titulo=titulo)

@app.route('/correos/')
@login_required
def correos():
    titulo ="Messaje Xpress Recibidos Correos"
    correo= session['user_id']
    try:
        mensajes=database.selectRecibidos(correo)
    except:
        return render_template('correo.html', titulo=titulo, datos=mensajes) 
    
    
    return render_template('correos.html', titulo=titulo, datos=mensajes)

@app.route('/newCorreo/', methods=['GET', 'POST'])
@login_required
def newCorreo():
    titulo = "Messaje Xpress New Correo"
    form=messaje()
    try:
        if request.method == 'POST':   
            destinatario= form.destinatario.data
            asunto = form.asunto.data
            mensaje = form.mensaje.data
            remitente= session['user_id']
            try:
                if database.selectEmail(destinatario):
                    database.insertMensaje(remitente,asunto,mensaje,destinatario)
                    flash ('Mensaje enviado')
                    return redirect ( url_for('sendCorreo') )
                else:
                    flash ('Correo no registrado en la plataforma')
                    return render_template('newCorreo.html', form=form, titulo=titulo)
            except:
                return render_template('newCorreo.html', form=form, titulo=titulo)
    except:
        return render_template('newCorreo.html', form=form, titulo=titulo)
    
    return render_template('newCorreo.html', form=form, titulo=titulo)


@app.route('/sendCorreo/')
@login_required
def sendCorreo():
    titulo ="Messaje Xpress Send Correo"
    correo= session['user_id']
    try:
        mensajes=database.selectEnviados(correo)
    except:
        return render_template('enviados.html', titulo=titulo, datos=mensajes) 
        
    return render_template('enviados.html', titulo=titulo, datos=mensajes)

@app.route('/logout/')
def logout():
    session.clear()
    flash("Has cerrado sesion de manera correcta")
    return redirect(url_for('index'))