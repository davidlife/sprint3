import sqlite3 as sql
from sqlite3 import Error
import hashlib
from werkzeug.security import check_password_hash
from datetime import date, datetime


def crearBD():
    try:
        conn = sql.connect('plataforma.db')
        conn.commit()
        conn.close()
    except Error:
        print(Error)

def crearTabla():
    conn = sql.connect('plataforma.db')
    cursor = conn.cursor()
    cursor.execute(
        """CREATE TABLE usuarios(
            usuario text,
            correo text PRIMARY KEY,
            password text,
            estado integer,
            key text
        )
        """
    )
    conn.commit()
    conn.close()
    
def crearTablaMensajes():
    conn = sql.connect('plataforma.db')
    cursor = conn.cursor()
    cursor.execute(
        """CREATE TABLE mensajes(
            remitente text,
            asunto text,
            mensaje text,
            destinatario text,
            fecha date
        )
        """
    )
    conn.commit()
    conn.close()
#crearTablaMensajes()
#crearTabla()

def insert(usuario, correo, password, key):
    conn = sql.connect('plataforma.db')
    cursor = conn.cursor()
    instruccion =f"INSERT INTO usuarios VALUES('{usuario}','{correo}','{password}', 2 ,'{key}')"
   
    cursor.execute(instruccion)
    conn.commit()
    conn.close()

def insertarElementos(listadoProductos):
    conn = sql.connect('plataforma.db')
    cursor = conn.cursor()
    instruccion =f"INSERT INTO inventario VALUES(?,?,?)"
    cursor.executemany(instruccion,listadoProductos)
    conn.commit()
    conn.close()
    
def selectUsuario(usuario):
    conn = sql.connect ('plataforma.db')
    cursor = conn.cursor()
    instruccion = f"SELECT * FROM usuarios where usuario='{usuario}'"
    cursor.execute(instruccion)
    datos=cursor.fetchone()
    conn.commit()
    conn.close()
    if datos is None:
        return False
    else:
        return True

def selectEmail(correo):
    conn = sql.connect ('plataforma.db')
    cursor = conn.cursor()
    instruccion = f"SELECT * FROM usuarios where correo = '{correo}'"
    cursor.execute(instruccion)
    correo=cursor.fetchone()
    conn.commit()
    conn.close()
    if correo is None:
        return False
    else:
        return True   


def consultarKey(usuario,key):
    conn = sql.connect ('plataforma.db')
    cursor = conn.cursor()
    instruccion = f"SELECT * FROM usuarios WHERE correo='{usuario}' AND key='{key}'"

    cursor.execute(instruccion)
    result=cursor.fetchone()
    conn.commit()
    conn.close()
    if result is None:
        return False
    else:
        return True  
    
def consultarUsuario(correo):
    conn = sql.connect ('plataforma.db')
    cursor = conn.cursor()
    instruccion = f"SELECT * FROM usuarios WHERE correo='{correo}'"
    cursor.execute(instruccion)
    user=cursor.fetchone()
    usuario=user[0]
    conn.commit()
    conn.close()
    return usuario

def activarkey(correo,key):
    conn = sql.connect('plataforma.db')
    cursor = conn.cursor()
    instruccion = f"UPDATE usuarios SET estado=1 WHERE correo='{correo}'"
    cursor.execute(instruccion)
    conn.commit()
    conn.close()
    if cursor is None:
        return False
    else:
        return True 
    
def validarUsuarioActivo(correo):
    conn = sql.connect('plataforma.db')
    cursor = conn.cursor()
    instruccion = f"SELECT * FROM usuarios WHERE correo='{correo}' AND estado=1"
    print (instruccion)
    cursor.execute(instruccion)
    user=cursor.fetchone()
    conn.commit()
    conn.close()
    if user is None:
        return False
    else:
        return True

def validarUsuario(correo,password):
    conn = sql.connect('plataforma.db')
    cursor = conn.cursor()
    instruccion = f"SELECT * FROM usuarios WHERE correo='{correo}' AND estado=1"
    cursor.execute(instruccion)
    user=cursor.fetchone()
    passwordUserBD=user[2]
    passwordComparar=check_password_hash(passwordUserBD,password)
    conn.commit()
    conn.close()
    if user is None or passwordComparar is False:
        return False
    else:
        return True
    
def insertMensaje(remitente, asunto, mensaje, destinatario):
    fecha = datetime.now().strftime("%y-%m-%d %H:%M")
    conn = sql.connect('plataforma.db')
    cursor = conn.cursor()
    instruccion =f"INSERT INTO mensajes VALUES('{remitente}','{asunto}','{mensaje}','{destinatario}', '{fecha}')"
    
    cursor.execute(instruccion)
    conn.commit()
    conn.close()
    
def selectEnviados(correo):
    conn = sql.connect ('plataforma.db')
    cursor = conn.cursor()
    instruccion = f"SELECT * FROM mensajes where remitente='{correo}' ORDER BY fecha DESC"
    cursor.execute(instruccion)
    datos=cursor.fetchall()
    conn.commit()
    conn.close()
    return datos

def selectRecibidos(correo):
    conn = sql.connect ('plataforma.db')
    cursor = conn.cursor()
    instruccion = f"SELECT * FROM mensajes where destinatario='{correo}'"
    cursor.execute(instruccion)
    datos=cursor.fetchall()
    conn.commit()
    conn.close()
    return datos

def usuarioSesionActual(correo):
    conn = sql.connect('plataforma.db')
    cursor = conn.cursor()
    instruccion = f"SELECT * FROM usuarios WHERE correo='{correo}'"
    cursor.execute(instruccion)
    user=cursor.fetchone()
    conn.commit()
    conn.close()
    return (user)

def usuarioConsultarkey(correo):
    conn = sql.connect('plataforma.db')
    cursor = conn.cursor()
    instruccion = f"SELECT * FROM usuarios WHERE correo='{correo}'"
    cursor.execute(instruccion)
    user=cursor.fetchone()
    conn.commit()
    conn.close()
    return (user[4])