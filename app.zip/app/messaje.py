from flask_wtf import FlaskForm
from wtforms import StringField, TextAreaField, SubmitField, EmailField
from wtforms.validators import DataRequired, Email, Length, InputRequired

class messaje(FlaskForm):
    
    destinatario = EmailField ('Correo electónico ', validators=[
        DataRequired(message="Rellene informacion"),
        Email(message='Email invalido')
    ])
    
    asunto = StringField ('asunto ', validators=[
        DataRequired(message="Rellene informacion"),
        Length(min=3, message='Supere los 3 caracteres')
    ])

    mensaje = TextAreaField('mensaje',validators=[
        InputRequired(),
        Length(max=200)])
    
    key = StringField ('Key ', validators=[
        DataRequired(message="Rellene informacion"),
        Length(min=6, message='Supere los 6 caracteres')
    ])
    
    ingresa=SubmitField('Enviar mensaje')
    