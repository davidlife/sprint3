from flask_wtf import FlaskForm
from wtforms import StringField, EmailField, PasswordField, SubmitField
from wtforms.validators import DataRequired, Email, Length

class activar(FlaskForm):
    
    key = StringField ('Key ', validators=[
        DataRequired(message="Rellene informacion"),
        Length(min=6, message='Supere los 6 caracteres')
    ])
    
    correo = EmailField ('Correo electónico ', validators=[
        DataRequired(message="Rellene informacion"),
        Email(message='Email invalido')
    ])
    
    activate=SubmitField('Activar cuenta')